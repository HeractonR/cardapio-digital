const el = id => document.getElementById(id);
const dinheiro = n => 'R$ ' + Number(n).toFixed(2).replace('.', ',');

// Cria um elemento com texto seguro (textContent nunca executa HTML)
function h(tag, classe, texto) {
  const e = document.createElement(tag);
  if (classe) e.className = classe;
  if (texto !== undefined) e.textContent = texto;
  return e;
}

let produtos = [];
const carrinho = {}; // { idDoProduto: quantidade }

async function carregar() {
  const categorias = await Banco.categorias();
  produtos = (await Banco.produtos()).filter(p => p.available);
  el('cardapio').innerHTML = '';
  categorias.forEach(cat => {
    const itens = produtos.filter(p => p.category_id === cat.id);
    if (!itens.length) return;
    const sec = h('section');
    sec.appendChild(h('h2', '', cat.name));
    itens.forEach(p => sec.appendChild(criarItem(p)));
    el('cardapio').appendChild(sec);
  });
}

function criarItem(p) {
  const box = h('div', 'item');
  const info = h('div');
  info.append(h('strong', '', p.name), h('p', 'desc', p.description || ''), h('span', 'preco', dinheiro(p.price)));
  const ctrl = h('div', 'qtd');
  const menos = h('button', 'menor', '−');
  const mais = h('button', 'menor', '+');
  const qtd = h('span', '', '0');
  qtd.id = 'q' + p.id;
  menos.setAttribute('aria-label', 'Remover ' + p.name);
  mais.setAttribute('aria-label', 'Adicionar ' + p.name);
  menos.onclick = () => mudar(p.id, -1);
  mais.onclick = () => mudar(p.id, 1);
  ctrl.append(menos, qtd, mais);
  box.append(info, ctrl);
  return box;
}

function mudar(id, delta) {
  const q = Math.max(0, (carrinho[id] || 0) + delta);
  if (q) carrinho[id] = q; else delete carrinho[id];
  atualizar();
}

function atualizar() {
  let total = 0, qtd = 0;
  el('resumo').innerHTML = '';
  produtos.forEach(p => {
    const q = carrinho[p.id] || 0;
    el('q' + p.id).textContent = q;
    if (!q) return;
    total += q * p.price;
    qtd += q;
    const linha = h('div', 'linha');
    linha.append(h('span', '', `${q}x ${p.name}`), h('span', '', dinheiro(q * p.price)));
    el('resumo').appendChild(linha);
  });
  el('total').textContent = dinheiro(total);
  el('barraTexto').textContent = `Ver pedido (${qtd}), ${dinheiro(total)}`;
  el('barra').hidden = qtd === 0;
  el('pedido').hidden = qtd === 0;
}

async function enviar() {
  const msg = el('mensagem');
  msg.textContent = '';
  const nome = el('nome').value.trim();
  const telefone = el('telefone').value.replace(/\D/g, '');
  const tipo = document.querySelector('input[name=tipo]:checked').value;
  const endereco = el('endereco').value.trim();
  const obs = el('obs').value.trim();
  const itens = produtos.filter(p => carrinho[p.id]).map(p => ({ id: p.id, name: p.name, qty: carrinho[p.id] }));

  if (!itens.length) return msg.textContent = 'Adicione pelo menos um item.';
  if (nome.length < 2) return msg.textContent = 'Digite seu nome.';
  if (telefone.length < 10) return msg.textContent = 'Digite um WhatsApp com DDD.';
  if (tipo === 'entrega' && endereco.length < 5) return msg.textContent = 'Digite o endereço de entrega.';

  const total = produtos.reduce((s, p) => s + (carrinho[p.id] || 0) * p.price, 0);
  el('enviar').disabled = true;
  try {
    await Banco.adicionarPedido({
      customer_name: nome, phone: telefone, type: tipo,
      address: tipo === 'entrega' ? endereco : null, notes: obs || null, items: itens, total
    });
  } catch (e) {
    el('enviar').disabled = false;
    return msg.textContent = 'Não foi possível salvar o pedido. Tente de novo.';
  }
  el('enviar').disabled = false;

  const linhas = itens.map(i => `${i.qty}x ${i.name}`).join('\n');
  const texto = `Olá! Pedido de ${nome}\n${linhas}\nTotal: ${dinheiro(total)}\n` +
    (tipo === 'entrega' ? `Entrega: ${endereco}` : 'Retirada no balcão') + (obs ? `\nObs.: ${obs}` : '');

  el('pedido').hidden = true;
  el('barra').hidden = true;
  el('cardapio').hidden = true;
  const ok = el('sucesso');
  ok.hidden = false;
  ok.innerHTML = '';
  const link = h('a', '', 'Avisar a lanchonete no WhatsApp');
  link.href = `https://wa.me/${WHATSAPP}?text=${encodeURIComponent(texto)}`;
  ok.append(h('h2', '', 'Pedido enviado'), h('p', '', 'Recebemos o seu pedido. Toque abaixo para avisar no WhatsApp e agilizar o preparo.'), link);
}

document.querySelectorAll('input[name=tipo]').forEach(r =>
  r.addEventListener('change', () => el('blocoEndereco').hidden = r.value !== 'entrega' || !r.checked));
el('enviar').addEventListener('click', enviar);
carregar();
