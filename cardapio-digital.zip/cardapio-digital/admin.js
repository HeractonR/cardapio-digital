const el = id => document.getElementById(id);
const dinheiro = n => 'R$ ' + Number(n).toFixed(2).replace('.', ',');
function h(tag, classe, texto) {
  const e = document.createElement(tag);
  if (classe) e.className = classe;
  if (texto !== undefined) e.textContent = texto;
  return e;
}

const logado = () => sessionStorage.getItem('painel') === 'ok';

function mostrar() {
  el('login').hidden = logado();
  el('painel').hidden = !logado();
  if (logado()) { listarPedidos(); carregarCategorias(); }
}

function aba(qual) {
  el('listaPedidos').hidden = qual !== 'pedidos';
  el('blocoProdutos').hidden = qual !== 'produtos';
  el('abaPedidos').setAttribute('aria-pressed', qual === 'pedidos');
  el('abaProdutos').setAttribute('aria-pressed', qual === 'produtos');
  if (qual === 'pedidos') listarPedidos(); else listarProdutos();
}

async function listarPedidos() {
  const inicio = new Date(); inicio.setHours(0, 0, 0, 0);
  const pedidos = (await Banco.pedidos()).filter(o => new Date(o.created_at) >= inicio);
  const lista = el('listaPedidos');
  lista.innerHTML = '';
  if (!pedidos.length) { lista.appendChild(h('p', 'aviso', 'Nenhum pedido hoje neste aparelho.')); return; }

  pedidos.forEach(o => {
    const caixa = h('div', 'caixa');
    const hora = new Date(o.created_at).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
    caixa.append(h('strong', '', `${hora}  ${o.customer_name}`));
    caixa.append(h('p', 'aviso', o.type === 'entrega' ? `Entrega: ${o.address}` : 'Retirada no balcão'));
    o.items.forEach(i => caixa.append(h('div', '', `${i.qty}x ${i.name}`)));
    if (o.notes) caixa.append(h('p', 'aviso', `Obs.: ${o.notes}`));
    const total = h('div', 'linha total');
    total.append(h('span', '', dinheiro(o.total)), h('span', 'st-' + o.status, o.status));
    caixa.append(total);

    const acoes = h('div', 'acoes');
    ['preparando', 'entregue', 'cancelado'].forEach(novo => {
      if (o.status === novo) return;
      const b = h('button', 'pequeno', novo);
      b.onclick = async () => { await Banco.atualizarPedido(o.id, { status: novo }); listarPedidos(); };
      acoes.appendChild(b);
    });
    const zap = h('a', '', 'WhatsApp');
    zap.href = `https://wa.me/55${o.phone}`;
    acoes.appendChild(zap);
    caixa.appendChild(acoes);
    lista.appendChild(caixa);
  });
}

async function carregarCategorias() {
  el('pCat').innerHTML = '';
  (await Banco.categorias()).forEach(c => {
    const o = h('option', '', c.name);
    o.value = c.id;
    el('pCat').appendChild(o);
  });
}

async function listarProdutos() {
  const lista = el('listaProdutos');
  lista.innerHTML = '';
  (await Banco.produtos()).forEach(p => {
    const caixa = h('div', 'caixa');
    caixa.append(h('strong', '', p.name));
    const preco = h('input');
    preco.type = 'number'; preco.step = '0.50'; preco.min = '0'; preco.value = p.price;
    preco.setAttribute('aria-label', 'Preço de ' + p.name);
    const disp = h('input');
    disp.type = 'checkbox'; disp.checked = p.available;
    const rotulo = h('label', '', ' Disponível');
    rotulo.prepend(disp);
    const salvar = h('button', 'pequeno', 'Salvar');
    salvar.onclick = async () => {
      await Banco.atualizarProduto(p.id, { price: Number(preco.value), available: disp.checked });
      salvar.textContent = 'Salvo';
    };
    const acoes = h('div', 'acoes');
    acoes.append(rotulo, salvar);
    caixa.append(preco, acoes);
    lista.appendChild(caixa);
  });
}

async function adicionarProduto() {
  const nome = el('pNome').value.trim();
  if (!nome || el('pPreco').value === '' || Number(el('pPreco').value) < 0) {
    el('pErro').textContent = 'Preencha o nome e o preço.';
    return;
  }
  await Banco.adicionarProduto({
    name: nome, description: el('pDesc').value.trim() || null,
    price: Number(el('pPreco').value), category_id: Number(el('pCat').value)
  });
  el('pErro').textContent = '';
  el('pNome').value = el('pDesc').value = el('pPreco').value = '';
  listarProdutos();
}

el('entrar').onclick = () => {
  const certa = el('senha').value === SENHA_PAINEL;
  el('erro').textContent = certa ? '' : 'Senha incorreta.';
  if (certa) { sessionStorage.setItem('painel', 'ok'); mostrar(); }
};
el('sair').onclick = () => { sessionStorage.removeItem('painel'); mostrar(); };
el('abaPedidos').onclick = () => aba('pedidos');
el('abaProdutos').onclick = () => aba('produtos');
el('pAdd').onclick = adicionarProduto;
mostrar();
