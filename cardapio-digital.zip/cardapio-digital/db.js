// Camada de dados: guarda tudo no navegador (localStorage), sem servidor.
// As funções são async de propósito: se um dia você ligar um back-end,
// basta trocar o conteúdo deste arquivo por chamadas fetch() e o resto do site continua igual.
const Banco = (() => {
  const CHAVES = { cat: 'cardapio_categorias', prod: 'cardapio_produtos', ped: 'cardapio_pedidos' };

  const ler = (chave, padrao) => {
    try { return JSON.parse(localStorage.getItem(chave)) ?? padrao; } catch { return padrao; }
  };
  const gravar = (chave, valor) => localStorage.setItem(chave, JSON.stringify(valor));
  const proximoId = lista => lista.reduce((maior, x) => Math.max(maior, x.id), 0) + 1;

  // Dados de exemplo na primeira visita
  if (localStorage.getItem(CHAVES.cat) === null) {
    gravar(CHAVES.cat, [
      { id: 1, name: 'Lanches', position: 1 },
      { id: 2, name: 'Porções', position: 2 },
      { id: 3, name: 'Bebidas', position: 3 }
    ]);
    gravar(CHAVES.prod, [
      { id: 1, category_id: 1, name: 'X-Burguer', description: 'Pão, hambúrguer, queijo e salada', price: 18, available: true },
      { id: 2, category_id: 1, name: 'X-Bacon', description: 'Pão, hambúrguer, queijo e bacon crocante', price: 22, available: true },
      { id: 3, category_id: 2, name: 'Batata frita', description: 'Porção para duas pessoas', price: 20, available: true },
      { id: 4, category_id: 3, name: 'Refrigerante lata', description: '350 ml', price: 6, available: true },
      { id: 5, category_id: 3, name: 'Suco natural', description: 'Laranja ou acerola, 400 ml', price: 9, available: true }
    ]);
    gravar(CHAVES.ped, []);
  }

  return {
    async categorias() { return ler(CHAVES.cat, []).sort((a, b) => a.position - b.position); },
    async produtos() { return ler(CHAVES.prod, []).sort((a, b) => a.name.localeCompare(b.name)); },

    async adicionarProduto(dados) {
      const lista = ler(CHAVES.prod, []);
      lista.push({ ...dados, id: proximoId(lista), available: true });
      gravar(CHAVES.prod, lista);
    },
    async atualizarProduto(id, campos) {
      gravar(CHAVES.prod, ler(CHAVES.prod, []).map(p => p.id === id ? { ...p, ...campos } : p));
    },

    async pedidos() {
      return ler(CHAVES.ped, []).sort((a, b) => b.created_at.localeCompare(a.created_at));
    },
    async adicionarPedido(dados) {
      const lista = ler(CHAVES.ped, []);
      lista.push({ ...dados, id: proximoId(lista), status: 'novo', created_at: new Date().toISOString() });
      gravar(CHAVES.ped, lista);
    },
    async atualizarPedido(id, campos) {
      gravar(CHAVES.ped, ler(CHAVES.ped, []).map(p => p.id === id ? { ...p, ...campos } : p));
    }
  };
})();
