# Cardápio digital com pedidos

Cardápio online para lanchonetes e restaurantes pequenos. O cliente monta o pedido pelo celular (retirada ou entrega) e envia pelo WhatsApp da lanchonete; o dono gerencia produtos, preços e pedidos em um painel.

**Problema que resolve:** taxas altas de apps de delivery e cardápio em foto de WhatsApp, que desatualiza e gera erro de pedido.

## Tecnologias
HTML, CSS e JavaScript puro. Dados salvos no navegador com `localStorage`, sem servidor e sem conta em nenhum serviço.

## Funcionalidades
- Cardápio por categorias com carrinho e total em tempo real
- Pedido para retirada ou entrega, com observações
- Mensagem de pedido pronta para o WhatsApp da lanchonete
- Painel do dono: pedidos do dia com status, cadastro de produtos, edição de preços e controle de disponibilidade
- Layout responsivo e modo escuro

## Como rodar
1. Edite `config.js` com o WhatsApp da lanchonete e a senha do painel.
2. Abra `index.html` (ou use a extensão Live Server do VS Code). O painel fica em `admin.html`.
3. Para publicar, use o GitHub Pages.

## Limitações conhecidas
- Os dados ficam no navegador de cada aparelho. Os pedidos chegam ao dono pelo WhatsApp; o painel registra os pedidos feitos no mesmo aparelho (por exemplo, um tablet de autoatendimento no balcão).
- A senha do painel fica no código e não protege de verdade. É só para demonstração.
- Para uso real com vários aparelhos, o próximo passo é trocar o `db.js` por um back-end com banco de dados. Todo o acesso aos dados passa por esse único arquivo, então o resto do site não muda.

## Próximos passos
- Back-end com banco de dados e login de verdade
- Taxa de entrega por bairro
- Fotos dos produtos
