// WhatsApp da lanchonete, com código do país e DDD (ex.: 5582999999999)
const WHATSAPP = '5582900000000';
// Senha do painel. Atenção: sem servidor, ela só serve para demonstração e não protege de verdade.
const SENHA_PAINEL = 'admin123';
